package com.umanizales.apibatallanaval.service;

import com.umanizales.apibatallanaval.model.dto.RespuestaDTO;
import com.umanizales.apibatallanaval.model.entities.Juego;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class JuegoService
{
    private Juego juego;
    @Autowired
    public  JuegoService(Juego juego){this.juego = juego;}

    public ResponseEntity<Object> findAll()
    {
        return new ResponseEntity<>(new RespuestaDTO("Juego",
                juego.findAll(),null), HttpStatus.OK);
    }




    public void crearJuego()
    {

    }
}
