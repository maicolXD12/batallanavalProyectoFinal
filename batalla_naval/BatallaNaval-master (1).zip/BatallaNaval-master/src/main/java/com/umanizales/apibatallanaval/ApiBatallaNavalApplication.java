package com.umanizales.apibatallanaval;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiBatallaNavalApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiBatallaNavalApplication.class, args);
    }

}
